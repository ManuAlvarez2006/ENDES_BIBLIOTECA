package com.endes.biblioteca;

public class Patron {
    private String name;
    private String address;

    public Patron(String name, String address) {
        this.name = name;
        this.address = address;
    }

    // Getters and Setters
}
