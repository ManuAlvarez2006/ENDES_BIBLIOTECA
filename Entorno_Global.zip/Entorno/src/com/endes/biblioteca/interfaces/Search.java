package com.endes.biblioteca.interfaces;

import com.endes.biblioteca.Book;

public interface Search {
    Book searchByTitle(String title);
    Book searchByISBN(String isbn);
}
