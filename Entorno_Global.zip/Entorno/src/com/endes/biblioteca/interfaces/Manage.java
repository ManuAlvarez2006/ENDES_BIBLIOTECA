package com.endes.biblioteca.interfaces;

import com.endes.biblioteca.Book;

public interface Manage {
    void addBook(Book book);
    void removeBook(Book book);
}
