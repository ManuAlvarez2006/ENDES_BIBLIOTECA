package com.endes.biblioteca;

public enum AccountState {
    FROZEN,
    ACTIVE,
    CLOSED
}
