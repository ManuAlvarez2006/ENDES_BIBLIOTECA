package com.endes.biblioteca;

import java.util.List;

public class Catalog {
    private List<Book> books;

    public Catalog(List<Book> books) {
        this.books = books;
    }

    // Métodos para agregar, buscar, eliminar libros
}
