package com.endes.biblioteca;

public class Book {
    private String ISBN;
    private String title;
    private String summary;
    private String publisher;
    private String publicationDate;
    private int numberOfPages;
    private String language;

    public Book(String ISBN, String title, String summary, String publisher, String publicationDate, int numberOfPages, String language) {
        this.ISBN = ISBN;
        this.title = title;
        this.summary = summary;
        this.publisher = publisher;
        this.publicationDate = publicationDate;
        this.numberOfPages = numberOfPages;
        this.language = language;
    }

    // Getters and Setters
}
