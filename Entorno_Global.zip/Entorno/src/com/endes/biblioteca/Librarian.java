package com.endes.biblioteca;

public class Librarian {
    private String name;
    private String address;
    private String position;

    public Librarian(String name, String address, String position) {
        this.name = name;
        this.address = address;
        this.position = position;
    }

    // Getters and Setters
}
