package com.endes.biblioteca;

public class Account {
    private String number;
    private Account state;

    public Account(String number, Account state) {
        this.number = number;
        this.state = state;
    }

    // Getters and Setters
}
